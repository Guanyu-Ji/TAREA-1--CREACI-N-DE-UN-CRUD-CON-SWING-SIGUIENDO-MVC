/**
 * 
 */
/**
 * 
 */
module taller {
	requires java.desktop;
}