package mesajeria.vistas;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import mesajeria.controlador.ConsultaMensajeroControlador;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ConsultaMensajeroVista extends JPanel {
	
	private JLabel tituloJLabel;
	private JTextField codigoTextField;
	private JLabel nombreRJLabel;
	private JLabel sueldoRJlabel;
	
	public ConsultaMensajeroVista() {
		System.out.println("Vista consulta mensajero");
		this.setLayout(null);
		
		JLabel consultaMensajeroJLabel = new JLabel("Consulta Mensajero");
		consultaMensajeroJLabel.setBounds(92, 12, 136, 25);
		add(consultaMensajeroJLabel);
		
		JLabel codigoJlabel = new JLabel("Codigo:");
		codigoJlabel.setBounds(70, 59, 60, 17);
		add(codigoJlabel);
		
		codigoTextField = new JTextField();
		codigoTextField.setBounds(114, 57, 114, 21);
		add(codigoTextField);
		codigoTextField.setColumns(10);
		
		JButton consultaButton = new JButton("Consulta\n");
		consultaButton.addActionListener(new ConsultaMensajeroControlador(this));
		consultaButton.setBounds(83, 102, 105, 27);
		add(consultaButton);
		
		JLabel nombreJLabel = new JLabel("Nombre:");
		nombreJLabel.setBounds(47, 160, 60, 17);
		add(nombreJLabel);
		
		nombreRJLabel = new JLabel("");
		nombreRJLabel.setBounds(129, 160, 129, 17);
		add(nombreRJLabel);
		
		JLabel lblSueldo = new JLabel("Sueldo:");
		lblSueldo.setBounds(47, 200, 60, 17);
		add(lblSueldo);
		
		sueldoRJlabel = new JLabel("");
		sueldoRJlabel.setBounds(128, 200, 60, 17);
		add(sueldoRJlabel);

	}
	
	public int getCodigo() throws NumberFormatException {
		return Integer.parseInt(codigoTextField.getText());
	}
	
	public void setSueldo(double sueldo) {
		sueldoRJlabel.setText(String.valueOf(sueldo));
	}
	
	public void setNombre(String nombre) {
		nombreRJLabel.setText(nombre);
	}
	
	public void lanzarError(String mensaje) {
		JOptionPane.showMessageDialog(JOptionPane.getFrameForComponent(nombreRJLabel),
				mensaje);

	}

}
