package mesajeria.vistas;

import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import mesajeria.controlador.BajaMensajeroControlador;

import javax.swing.JButton;

public class BajaMensajeroVista extends JPanel{
	private JTextField codigotextField;
	public BajaMensajeroVista() {
		setLayout(null);
		
		JLabel codigoLabel = new JLabel("Codigo:");
		codigoLabel.setBounds(39, 59, 60, 17);
		add(codigoLabel);
		
		JLabel tituloLabel = new JLabel("Baja Mensajero");
		tituloLabel.setBounds(103, 12, 91, 17);
		add(tituloLabel);
		
		codigotextField = new JTextField();
		codigotextField.setBounds(117, 57, 114, 21);
		add(codigotextField);
		codigotextField.setColumns(10);
		
		JButton bajaJButton = new JButton("Baja");
		bajaJButton.setBounds(68, 103, 105, 27);
		add(bajaJButton);
		bajaJButton.addActionListener(new BajaMensajeroControlador(this));
	}
	
	public int getCodigo() {
		return Integer.parseInt(codigotextField.getText());
	}
	
	public void lanzarError(String mensaje) {
		JOptionPane.showMessageDialog(JOptionPane.getFrameForComponent(codigotextField),
				mensaje);

	}
	
	public void bajaOk() {
		JOptionPane.showMessageDialog(JOptionPane.getFrameForComponent(codigotextField),
				"Baja correcta.");
	}
}
