package mesajeria.vistas;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import mesajeria.controlador.ModificacionMensajeroControlador;

public class ModificacionMensajeroVista extends JPanel{
	private JTextField CodigotextField;
	private JTextField NombretextField_1;
	private JTextField SueldotextField_2;
	public ModificacionMensajeroVista() {
		this.setLayout(null); 
		
		JLabel lblNewLabel = new JLabel("New label");
		add(lblNewLabel);
		
		JLabel ModificacionlblNewLabel_1 = new JLabel("Modificacion Mensajero");
		ModificacionlblNewLabel_1.setBounds(136, 12, 177, 14);
		add(ModificacionlblNewLabel_1);
		
		JLabel CodigolbNewLabel_1 = new JLabel("Codigo");
		CodigolbNewLabel_1.setBounds(49, 58, 46, 14);
		add(CodigolbNewLabel_1);
		
		JLabel NombrelblNewLabel_1 = new JLabel("Nombre");
		NombrelblNewLabel_1.setBounds(49, 93, 91, 17);
		add(NombrelblNewLabel_1);
		
		JLabel SueldolblNewLabel_2 = new JLabel("Sueldo");
		SueldolblNewLabel_2.setBounds(49, 126, 46, 14);
		add(SueldolblNewLabel_2);
		
		CodigotextField = new JTextField();
		CodigotextField.setBounds(158, 55, 86, 20);
		add(CodigotextField);
		CodigotextField.setColumns(10);
		
		NombretextField_1 = new JTextField();
		NombretextField_1.setBounds(158, 91, 86, 20);
		add(NombretextField_1);
		NombretextField_1.setColumns(10);
		
		SueldotextField_2 = new JTextField();
		SueldotextField_2.setBounds(158, 123, 86, 20);
		add(SueldotextField_2);
		SueldotextField_2.setColumns(10);
		
		JButton ModificarbtnNewButton = new JButton("Modificar");
		ModificarbtnNewButton.setBounds(147, 171, 139, 23);
		add(ModificarbtnNewButton);
		
		ModificacionMensajeroControlador Mcontrolador=
				new ModificacionMensajeroControlador(this);		
		ModificarbtnNewButton.addActionListener(Mcontrolador);
	}
	
	public String getNombre() {
		return NombretextField_1.getText();
	}
	
	public int getCodigo() {
		return Integer.parseInt(CodigotextField.getText());
	}
	
	public double getSueldo() {
		return Double.parseDouble(SueldotextField_2.getText());
	}
	
	public void lanzarError(String mensaje) {
		JOptionPane.showMessageDialog(JOptionPane.getFrameForComponent(SueldotextField_2),
				mensaje);

	}
	
	public void lanzarOk() {
		JOptionPane.showMessageDialog(JOptionPane.getFrameForComponent(SueldotextField_2),
				"Modificacion correcta.");
		CodigotextField.setText("");
		NombretextField_1.setText("");
		SueldotextField_2.setText("");
	}

} 
