package mesajeria.modelo;

public class APIMensajeria {
	
	private Mensajeria mensajeria;
	
	private static APIMensajeria instancia;
	
	private APIMensajeria() {
		mensajeria=new Mensajeria();
	}
	
	
	public static APIMensajeria getInstance() {
		if (instancia==null)  {
			instancia=new APIMensajeria();		
		}
		return instancia;
	}
	
	
	public void altaMensajero(String nombre, double sueldo) {
		mensajeria.altaMensajero(nombre, sueldo, 5);
	}
	
	public String[] consultarMensajero(int codigo) {
		String[] resultado=new String[2];
		Mensajero m=mensajeria.buscarMensajeroPorCodigo(codigo);
		resultado[0]=m.getNombre();
		resultado[1]=String.valueOf(m.getSueldo());
		
		return resultado;
	}
	
	public boolean bajaMensajero(int codigo) {
		return mensajeria.bajaMensajero(codigo);
	}
	
	public boolean modificarMensajero(int codigo, String nombre, double sueldo) {
		return mensajeria.modificarMensajero(codigo, nombre, sueldo);
	}

}
