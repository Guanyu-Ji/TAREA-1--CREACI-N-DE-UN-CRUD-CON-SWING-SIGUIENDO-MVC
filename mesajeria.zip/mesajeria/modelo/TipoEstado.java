package mesajeria.modelo;

public enum TipoEstado {
	EN_ESPERA, ASIGNADO, ENTREGADO
}
