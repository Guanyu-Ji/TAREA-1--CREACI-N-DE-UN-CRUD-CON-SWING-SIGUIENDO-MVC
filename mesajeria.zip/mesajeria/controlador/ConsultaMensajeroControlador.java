package mesajeria.controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import mesajeria.modelo.APIMensajeria;
import mesajeria.vistas.ConsultaMensajeroVista;

public class ConsultaMensajeroControlador implements ActionListener {
	
	private ConsultaMensajeroVista vista;
	private APIMensajeria api=APIMensajeria.getInstance();
	
	public ConsultaMensajeroControlador(ConsultaMensajeroVista vista) {
		this.vista=vista;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		System.out.println("Evento ConsultaMensajeroVista");
	
		
		String[] resultado=new String[2];
		try {
			System.out.println(vista.getCodigo());
			resultado=api.consultarMensajero(vista.getCodigo());		
			// Lllamo al modelo
			vista.setNombre(resultado[0]);
			vista.setSueldo(Double.parseDouble(resultado[1]));
		} catch (NumberFormatException ex) {
			System.out.println("Exception: Codigo no numerico");
			vista.lanzarError("El codigo no es numerico.");
		} catch (NullPointerException exn) {
			System.out.println("Exception:  No se han encontrador resultado");
			vista.lanzarError("Codigo no existe");
		}
		
	}

}
