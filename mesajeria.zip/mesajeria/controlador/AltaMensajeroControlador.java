package mesajeria.controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JTextField;

import mesajeria.modelo.APIMensajeria;
import mesajeria.modelo.Mensajeria;
import mesajeria.vistas.AltaMensajeroVista;

public class AltaMensajeroControlador implements ActionListener {
	
	private AltaMensajeroVista vista;
	private APIMensajeria api=APIMensajeria.getInstance();
	
	
	public AltaMensajeroControlador(AltaMensajeroVista vista) {
		this.vista=vista;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		try {
			System.out.println("Nombre: "+vista.getNombre());
			System.out.println("Sueldo: "+vista.getSueldo());
			String nombre=vista.getNombre();
			double sueldo=vista.getSueldo();
			api.altaMensajero(nombre, sueldo);
			vista.lanzarOk();
		}
		catch(NumberFormatException nfe) {
			System.out.println("Excepcion:Sueldo no numerico");
			vista.lanzarError("Sueldo no numerico");
		}
		
		
	}
	

	


}
