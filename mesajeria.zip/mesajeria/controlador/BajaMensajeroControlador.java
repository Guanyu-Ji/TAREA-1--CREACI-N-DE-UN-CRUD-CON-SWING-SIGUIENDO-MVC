package mesajeria.controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import mesajeria.modelo.APIMensajeria;
import mesajeria.vistas.BajaMensajeroVista;

public class BajaMensajeroControlador implements ActionListener{
	
	private BajaMensajeroVista vista;
	private APIMensajeria api=APIMensajeria.getInstance();
	
	public BajaMensajeroControlador(BajaMensajeroVista vista) {
		this.vista=vista;
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		System.out.println(vista.getCodigo());
		if (api.bajaMensajero(vista.getCodigo())) {
			System.out.println("Baja correcta");
			vista.bajaOk();
		}
		else {
			System.out.println("Mensajero no encontrado");
			vista.lanzarError("Codigo no encontrado");
		}
	}

}
