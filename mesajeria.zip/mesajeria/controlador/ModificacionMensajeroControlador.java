package mesajeria.controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import mesajeria.modelo.APIMensajeria;
import mesajeria.vistas.ModificacionMensajeroVista;

public class ModificacionMensajeroControlador implements ActionListener{

	private ModificacionMensajeroVista vista;
	private APIMensajeria api=APIMensajeria.getInstance();
	
	public ModificacionMensajeroControlador(ModificacionMensajeroVista vista) {
		this.vista=vista;
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		System.out.println("Evento de la vista Modificacion recibido");
		try {
			int codigo=vista.getCodigo();
			String nombre=vista.getNombre();
			double sueldo=vista.getSueldo();
			if (api.modificarMensajero(codigo, nombre, sueldo)) {
				vista.lanzarOk();
			}
			else {
				vista.lanzarError("Mensajero no encontrado");
			}
		}
		catch (NumberFormatException ex) {
			System.out.println("Error de formato de numero.");
			vista.lanzarError("Error de formato de numero.");
		}
		
	}

}
